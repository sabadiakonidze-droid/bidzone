# BidZone 3.0 — mobile demo

Open `index.html` in a modern browser or publish the folder to static hosting.

## Implemented
- Responsive mobile-first UI, categories, search, auction status filters, bottom navigation
- Product detail pages with gallery, description and specifications
- Independent auction timers and prices, 0.01 GEL increments, last-5-second reset
- Bid history, demo profile, virtual balance, favorites, winners, localStorage persistence
- Rules/help page

## Not implemented (requires backend)
- Real authentication and accounts
- Server-authoritative bids, database transactions, concurrent multiuser auctions, audit logs
- Payments, real inventory, fulfillment, legal review

The demo uses third-party Unsplash image URLs; internet is required for images and the images are illustrative, not exact item photography. Do not enter passwords or personal information. Demo values are not money. For production use Supabase Auth + Postgres RPC with row locks and security policies, server-authoritative time, and separate admin roles.

To deploy on iPhone, use a GitHub repository via mobile browser and connect Netlify to that repository. Netlify Drop folder upload may be limited on mobile Safari.
